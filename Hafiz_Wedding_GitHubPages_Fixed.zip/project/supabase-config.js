// Supabase configuration for GitHub Pages.
// The publishable/anon key is safe to use in browser code when Row Level Security is enabled.
const SUPABASE_URL = "https://nphzfbdtejvvuctydhof.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_HMcmA96cZ3Huk7RsGkbKfg_Aolv6e8Y";
