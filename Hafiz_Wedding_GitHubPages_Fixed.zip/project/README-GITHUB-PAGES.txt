1. Upload Index.html and supabase-config.js to the GitHub repository root.
2. In Supabase, run supabase-setup.sql in SQL Editor.
3. In Supabase Authentication, create the login user with the email/password you want.
4. GitHub Pages must be configured to deploy from the repository root.
5. Open the GitHub Pages URL.
